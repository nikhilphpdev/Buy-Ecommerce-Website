<?php
/*ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
 error_reporting(E_ALL);
*/
session_start();
include_once('../config_db/conn_connect.php');
$conn = conndata();

header("Content-Type: application/json");

// Receive JSON RAW body
$data = json_decode(file_get_contents("php://input"), true);

$bill_number = $data['bill_number'] ?? '';
$user_id = $data['user_id'] ?? '';
$image       = $data['image'] ?? ''; // base64 image

// USER ID FROM SESSION
if (!isset($user_id)) {
    echo json_encode([
        "status" => 401,
        "message" => "User not logged in"
    ]);
    exit;
}
if ($bill_number == "") {
    echo json_encode([
        "status" => "error",
        "message" => "Bill number is required"
    ]);
    exit;
}
// Duplicate check
$check = $conn->prepare("
    SELECT bill_number, luckydraw_code 
    FROM customer_luckydraw 
    WHERE bill_number = ?
");
$check->bind_param("s", $bill_number);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc();

    echo json_encode([
        "status" => "400",
        "bill_number" => $row['bill_number'],
        "luckycode" => $row['luckydraw_code'],
        "message" => "You have already submitted Lucky Draw"
    ]);
    exit;
}
function generateUniqueCoupon($conn, $prefix = "BUYJEE", $length = 4) {

    do {
        // Generate random number with leading zeros
        $code = $prefix . str_pad(rand(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);

        // Prepare DB query
        $check = $conn->prepare("SELECT luckydraw_code FROM customer_luckydraw WHERE luckydraw_code = ?");
        $check->bind_param("s", $code);
        $check->execute();
        $result = $check->get_result();

    } while ($result->num_rows > 0); 

    return $code;
}


$luckycode = generateUniqueCoupon($conn); 
// Required fields check
if (empty($bill_number) || empty($image)) {
    echo json_encode([
        "status" => 400,
        "message" => "Bill number and image are required"
    ]);
    exit;
}


// Base64 validation
if (strpos($image, "data:image") === 0) {
    $image = explode(",", $image)[1]; // remove header
}

$decodedImage = base64_decode($image);
if (!$decodedImage) {
    echo json_encode([
        "status" => 400,
        "message" => "Invalid base64 image"
    ]);
    exit;
}
$fileName = "lucky_" . time() . "_" . rand(1000, 9999) . ".png";
$filePath = "../luckydraw/" . $fileName;

if (!is_dir("../luckydraw")) {
    mkdir("../luckydraw", 0777, true);
}
file_put_contents($filePath, $decodedImage);

// CHECK IF USER ALREADY SUBMITTED LUCKY DRAW
$checkUser = $conn->prepare("
    SELECT id,luckydraw_code,bill_number  FROM customer_luckydraw 
    WHERE customer_ui_id = ?
    LIMIT 1
");
$checkUser->bind_param("s", $user_id);
$checkUser->execute();
$checkResult = $checkUser->get_result();


if ($checkResult->num_rows > 0) {
    $row = $checkResult->fetch_assoc();

    echo json_encode([
        "status" => 409,
        "bill_number" => $row['bill_number'],
        "luckycode" => $row['luckydraw_code'],
        "message" => "You have already used Lucky Draw."
    ]);
    exit;
}

$sql = $conn->prepare("
    INSERT INTO customer_luckydraw (customer_ui_id,luckydraw_code, bill_number, image) 
    VALUES (?, ?, ?, ?)
");

$sql->bind_param("ssss", $user_id,$luckycode, $bill_number, $fileName);

if ($sql->execute()) {
    echo json_encode([
        "status" => 200,
        "message" => "Image uploaded successfully",
        "bill_number" => $bill_number,
        "luckycode" => $luckycode,
        "user_id" =>$user_id,
        "image_url" => "https://testing.buyjee.com/luckydraw/" . $fileName
    ]);
} else {
    echo json_encode([
        "status" => 500,
        "message" => "DB insert failed"
    ]);
}
?>
